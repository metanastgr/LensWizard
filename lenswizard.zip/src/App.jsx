import { useState } from 'react'

//components
import FilterBox from './components/FilterBox'
import Toggler from './components/Toggler'
import Results from './components/Results'
import Footer from './components/Footer'

function App() {

  const [filterModal,setFilterModal] = useState(true)


  const closeFilters = () => {
    setFilterModal(false)
  }

  const toggleFilters = () => {
    setFilterModal(!filterModal)
  }


  return (
    <>
      <FilterBox 
      closer={closeFilters}
      isOpen={filterModal}/>

      <Results/>
      <Toggler toggle={toggleFilters}/>
      <Footer />

    </>
  )
}

export default App
