import React, { useState } from 'react'
import { Close } from '../data/icons';
import { options } from '../data/options'

//components
import Option from './Option';


function FilterBox({ isOpen, closer }) {

  if (!isOpen) return null;

  return (
    <>
      <div className="overlay" />

      <div className="filterbox">
        <div className="close" onClick={closer}>
          <Close />
        </div>

        <div className="headings">
          <div className="title">LensWizard</div>
          <div className="desc">Choose photography type</div>
        </div>


        {/* photography type options  */}

        <div className="options">
          {options.map((option, index) => {
            const Icon = option.icon;
            return (
              <Option key={index} lbl={option.label} icon={<Icon />} />
            );
          })}
        </div>



        <div className="buttons">
          <div className="btn">Apply Filters</div>
        </div>
      </div>
    </>
  )
}

export default FilterBox;