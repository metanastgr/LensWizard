import React from 'react'

function Lense() {
    return (
        <div className="lensebox">
            <div className="ic-lense"></div>

            <div className="details">
                <div className="info">
                    <div className="title">Length</div>
                    <div className="value">100-400mm</div>
                </div>
                <div className="info">
                    <div className="title">Apperture</div>
                    <div className="value">f/5.6</div>
                </div>
            </div>
        </div>
    )
}

export default Lense