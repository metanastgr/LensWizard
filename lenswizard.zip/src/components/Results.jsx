import React from 'react'

import Lense from './Lense'
function Results() {
    return (
        <div className="results">
            <Lense />
            <Lense />
            <Lense />
            <Lense />
            <Lense />
            <Lense />
        </div>
    )
}

export default Results