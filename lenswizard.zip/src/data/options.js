import { Macro, Portrait, LandScape, WildLife, Street, Astrophoto } from "./icons"



export const options = [
    {
        "label": "Portraits",
        "icon": Portrait
    },

    {
        "label": "Street",
        "icon": Street
    },

    {
        "label": "Landscape",
        "icon": LandScape
    },

    {
        "label": "Macro",
        "icon": Macro
    },

    {
        "label": "Wild Life",
        "icon": WildLife    
    },

    {
        "label": "Astrophoto",
        "icon": Astrophoto
    },




]