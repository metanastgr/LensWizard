import React from 'react'
import { Filters } from '../data/icons'


function Toggler({toggle}) {
    return (
        <div className="toggler" onClick={toggle}>
            <Filters />
        </div>
    )
}

export default Toggler