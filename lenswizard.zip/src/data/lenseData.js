export const lensSuggestions = {
    Portraits: [
      "85mm f/1.8",
      "50mm f/1.4",
      "70-200mm f/2.8"
    ],
    Street: [
      "35mm f/1.8",
      "28mm f/2.8",
      "50mm f/1.8"
    ],
    Landscape: [
      "16-35mm f/4",
      "14mm f/2.8",
      "24mm f/1.4"
    ],
    Macro: [
      "100mm f/2.8 Macro",
      "60mm f/2.8 Macro",
      "150mm f/2.8 Macro"
    ],
    "Wild Life": [
      "100-400mm f/5.6",
      "150-600mm f/5-6.3",
      "600mm f/4"
    ],
    Astrophoto: [
      "14mm f/2.8",
      "24mm f/1.4",
      "Sigma 20mm f/1.4 Art"
    ]
  };
  